=== Assamese Font by Lachit ===
Contributors: lachitorg
Donate link: https://lachit.org/
Tags: assamese font, assamese typography, jonaki font, lakhimi font, assamese plugin
Requires at least: 5.2
Tested up to: 6.7
Version: 1.0
Stable tag: 1.0
Requires PHP: 5.6
License: GPLv3 or later
License URI: http://www.gnu.org/licenses/gpl-3.0.html

Make Assamese text on your website clear and visually appealing, improving readability and enhancing the overall content presentation.

== Description ==

Many Assamese WordPress users face issues with displaying Assamese fonts properly on their websites. Standard plugins often fall short in providing a polished and aesthetic solution. 

**Assamese Font by Lachit** is a free and user-friendly plugin designed to make Assamese text on your site look beautiful and legible. It supports popular Assamese fonts like Jonaki, Lakhimi, Chitra, and Gitanjali. With just a simple activation, your Assamese content will be transformed into a clean, attractive presentation for your audience.

### Key Features:
- Supports popular Assamese fonts.
- Compatible with all WordPress themes.
- Easy activation – no configuration required.
- Improves the typography of Assamese websites.

== Installation ==

1. Unpack the entire contents of this plugin zip file into your `wp-content/plugins/` folder locally.
2. Upload the folder to your site.
3. Navigate to `wp-admin/plugins.php` on your site (your WP Admin plugin page).
4. Activate this plugin.

**Alternative Installation**:
1. Go to `Plugins > Add New` in your WordPress admin panel.
2. Search for "Assamese Font by Lachit."
3. Install and activate the plugin directly from there.

== Frequently Asked Questions ==

= Can I use this plugin with any WordPress site? =  
Yes, this plugin is compatible with all WordPress sites, regardless of the theme or setup.

= What fonts are included? =  
The plugin includes popular Assamese fonts like Jonaki, Lakhimi, Chitra, and Gitanjali.

= Does it require any configuration? =  
No, simply activate the plugin, and it will automatically apply the selected Assamese font.

== Screenshots ==
1. Screenshot of the Jonaki font applied on a WordPress site.
2. Settings panel for selecting fonts in the admin dashboard.

== Upgrade Notice ==

It's safe to upgrade this plugin anytime. New features and bug fixes are regularly added to improve performance.

== Changelog ==

= 1.0.0 – Jan 12, 2025 =
* Initial release with 4 Assamese fonts: Jonaki, Lakhimi, Chitra, and Gitanjali.
* Optimized for WordPress 6.7.
* Compatible with PHP 5.6 and above.

== Future Updates ==

Planned features include:
- Support for additional Assamese fonts.
- Advanced typography settings in the admin dashboard.
- Improved compatibility with page builders like Elementor and WPBakery.
